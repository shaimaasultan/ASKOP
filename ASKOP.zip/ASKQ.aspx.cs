﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


namespace ASKOP
{
    public partial class ASKQ : System.Web.UI.Page
    {
        private DataTable answerData;
        private WatsonQA qaService;
        const int margin = 5;
        const int textgap = 8;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.qaService = new WatsonQA("healthcare",
                                          "https://gateway.watsonplatform.net/question-and-answer-beta/api",
                                          "bb799249-411f-48b6-949d-79725bb23fd1", "zhfQoW6mFAGO");
            answerData = new DataTable("List");
            answerData.Columns.Add("Answer", typeof(string));
            answerData.Columns.Add("Confidence", typeof(string));
        }
        private void loadAnswerData(string question)
        {
            answerData.Clear();

            //call Watson
            var response = this.qaService.AskQuestion(question);
            //parse JSON response
            JArray payload = JArray.Parse(response);
            //obtain answer items we are interested in
            var answerList =
                 from p in payload[0]["question"]["evidencelist"]
                 select new
                 {
                     Answer = p["text"],
                     Confidence = p["value"]
                 };
            //populate the list box with answers
            foreach (var a in answerList)
            {
                answerData.Rows.Add(new object[] { a.Answer, a.Confidence });
            }
        }

        protected void AsKbtn_Click(object sender, EventArgs e)
        {
            //call Watson
            loadAnswerData(this.questionBox.Value);
            //clear existing question and any previous search results
            this.questionBox.Value = "";
            

             formatDataTable(answerData);
            
           
        }
        DataTable formatDataTable(DataTable dt)
        {
            DataTable formatedDataTable = new DataTable();
            DataColumn dc = new DataColumn("ID");
            formatedDataTable.Columns.Add(dc);
            dc = new DataColumn("result");
            formatedDataTable.Columns.Add(dc);
            Literal1.Text = string.Empty;
            int i =1;
           
            
            foreach(DataRow dr in dt.Rows)
            {
                DataRow fdr = formatedDataTable.NewRow();
                fdr["ID"] = i;
                string res = (dr[0].ToString() + Environment.NewLine + " Confidence: " + Convert.ToDouble(dr[1]).ToString("P2"));
          
                fdr["result"] =   res;
                formatedDataTable.Rows.Add(fdr);
                ++i;
                var height = res.Length <= 400 ? 100 : 150 + (res.Length - 400)/2;
                string result = @"<div class='row 50%'>
								<div class='12u'>
                                    <textarea placeholder='Result'  style='height:" + height + @"px' id='Result" + i + @"' name='Result" + i + @"'>" + i + " - " + res + @"</textarea>
								</div>
							</div>";
                Literal1.Text += result;
                
            }
           
            
            return formatedDataTable;
        }
        
    }
}